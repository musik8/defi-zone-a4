import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-topdefi',
  templateUrl: './topdefi.page.html',
  styleUrls: ['./topdefi.page.scss'],
})
export class TopdefiPage implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
