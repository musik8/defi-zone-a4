export interface Iprotocol {
    id: number,
    name: string


}