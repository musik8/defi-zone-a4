//Create Interface 
export class Defi {
    id: number;
    lama_id: string;
}

export class Token {
    id: number;
    geckoID: string;
    amount: number;
    FavID: any[];
}

