CREATE TABLE IF NOT EXISTS defitable(
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    defi_name TEXT, 
    tvl_value TEXT
);

INSERT or IGNORE INTO defitable(id, defi_name, tvl_value) VALUES (0, 'Curv', '20,000,000,000');
INSERT or IGNORE INTO defitable(id, defi_name, tvl_value) VALUES (1, 'AAVE', '15,000,000,000');
