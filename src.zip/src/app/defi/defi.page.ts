
import { Component, OnInit } from '@angular/core';
import { FormGroup, FormBuilder } from "@angular/forms";
import { DbService } from './../services/db.service'
import { ActivatedRoute, Router } from "@angular/router";
import { LamaService } from '../services/API/lama.service';

@Component({
  selector: 'app-defi',
  templateUrl: './defi.page.html',
  styleUrls: ['./defi.page.scss'],
})
export class DefiPage implements OnInit {
  editForm: FormGroup;
  slug: any;
  protoDetail: any; 
  
  constructor(
    private db: DbService,
    private router: Router,
    public formBuilder: FormBuilder,
    private actRoute: ActivatedRoute,
    private lamaService: LamaService 
  ) {
    this.slug = this.actRoute.snapshot.paramMap.get('id');
    console.log(this.slug)
    // this.db.getSong(this.id).then(res => {
    //   this.editForm.setValue({
    //     defi_name: res['defi_name'],
    //     tvl_value: res['tvl_value']
    //   })
    // })
  }

  ngOnInit() {
    this.editForm = this.formBuilder.group({
      defi_name: [''],
      tvl_value: ['']
    })

    this.lamaService.getProtocol(this.slug).subscribe(
      (data) => {
       // console.log(data);
       // console.log(data.length); 
        //data.sort((a,b) => a.title.rendered.localeCompare(b.title.rendered));
        this.protoDetail = data
        console.log(data)
      
      
      },
      (error) => console.log('error', error),
   );
  }

  saveForm(){
    // this.db.updateSong(this.id, this.editForm.value)
    // .then( (res) => {
    //   console.log(res)
    //   this.router.navigate(['/home']);
    // })
  }

}