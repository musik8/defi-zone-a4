export class Defi {
    id: number;
    defi_name: string;
    tvl_value: string;
}
