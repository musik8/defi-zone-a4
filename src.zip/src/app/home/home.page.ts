
import { Component, OnInit } from '@angular/core';
import { FormGroup, FormBuilder } from "@angular/forms";
import { DbService } from './../services/db.service';
import { ToastController } from '@ionic/angular';
import { Router } from "@angular/router";
import { LamaService } from '../services/API/lama.service';
import { Observable } from 'rxjs';


@Component({
  selector: 'app-home',
  templateUrl: 'home.page.html',
  styleUrls: ['home.page.scss'],
})
export class HomePage {

  mainForm: FormGroup;
  Data: any[] = [];
  topDefi: any;
  //allDefi: Observable<any>;
  allDefi: any;
  data: any; 
  constructor(
    private db: DbService,
    public formBuilder: FormBuilder,
    private toast: ToastController,
    private router: Router,
    private lamaService: LamaService 
  ) {
    
  }

  ionViewWillEnter() {
    // Load the data
    // this.lamaService.prepareDataRequest()
    //   .subscribe(
    //     data => {
    //       // Set the data to display in the template
    //       this.data = JSON.stringify(data);
    //     }
    //   );


     this.lamaService.prepareDataRequest().subscribe(
        (data) => {
         // console.log(data);
         // console.log(data.length); 
          //data.sort((a,b) => a.title.rendered.localeCompare(b.title.rendered));
          this.data = data
        
        
        },
        (error) => console.log('error', error),
     );

  }

  ngOnInit() {

    //Get All protocls
    //this.lamaService.getAllTest().subscribe(data => this.allDefi = data);
    //this.allDefi = this.lamaService.getAllTest();

    //Get saved defi protocls from database
    // this.db.dbState().subscribe((res) => {
    //   if(res){
    //     this.db.fetchSongs().subscribe(item => {
    //       this.Data = item
    //     })
    //   }
    // });
  
    this.mainForm = this.formBuilder.group({
      artist: [''],
      song: ['']
    })
  }

  searchData() {
   
  }
  sortProtocols() {
     //console.log(this.allDefi);
    //this.data.sort((a,b) => a.mcap.rendered.localeCompare(b.mcap.rendered));
 
    console.log(this.data.length);
    console.log(this.data.sort((a, b) => b.tvl - a.tvl))
    this.topDefi = this.data.sort((a, b) => b.tvl - a.tvl).slice(0,10);
    console.log(this.topDefi)
    // this.db.addSong(
    //   this.mainForm.value.artist,
    //   this.mainForm.value.song
    // ).then((res) => {
    //   this.mainForm.reset();
    // })
  }


  deleteSong(id){
    this.db.deleteSong(id).then(async(res) => {
      let toast = await this.toast.create({
        message: 'Song deleted',
        duration: 2500
      });
      toast.present();      
    })
  }

}
