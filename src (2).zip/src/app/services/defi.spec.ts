import { Defi } from './defi';

describe('Defi', () => {
  it('should create an instance', () => {
    expect(new Defi()).toBeTruthy();
  });
});
